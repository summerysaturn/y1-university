

select * from  vCustOrderDisplay
order by customerID