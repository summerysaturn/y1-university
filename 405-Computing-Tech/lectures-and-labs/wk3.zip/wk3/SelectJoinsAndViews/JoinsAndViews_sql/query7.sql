/* use this as a model for your own view from your own database
	-has different column names
	-uses a condition to filter the records (this one shows current employlees only)
	-suggestions - orders with total value over $x?
				- customers who made orders before a certain date

DROP VIEW vEmpDeptHist  //in case on with the same name exists
GO
//sample to work from

CREATE VIEW vEmpDeptHist

AS

SELECT EmployeeID, DepartmentID, StartDate, EndDate 
FROM HumanResources.EmployeeDepartmentHistory
WHERE EndDate IS NULL   */