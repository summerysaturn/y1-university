/***edit this to use your own db****/
/*      use XXXXXXX    */
/***edit this to use your own db****/

SELECT SalesOrderID, OrderDate, tOrder.CustomerID,
fName, sName

FROM tOrder

INNER JOIN tCust

ON CustomerID = tCust.CustID

WHERE tOrder.CustomerID = 2

ORDER BY  OrderDate



