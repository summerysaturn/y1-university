/*use my ci402_teaching database, 
where tCust2 is to make this point*/

use ci402_teaching
go

SELECT SalesOrderID, 
OrderDate, 
CustomerID, 
fName, 
sName,
City
FROM tOrder
INNER JOIN tCust2
ON tOrder.CustomerID = tCust2.CustomerID

/*edit query to make it work - look for ambiguous 
error in slides*/
