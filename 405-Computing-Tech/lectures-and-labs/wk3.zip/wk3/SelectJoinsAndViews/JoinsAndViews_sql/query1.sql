select CustID, fName, sname, city 
from tCust
order by CustID
