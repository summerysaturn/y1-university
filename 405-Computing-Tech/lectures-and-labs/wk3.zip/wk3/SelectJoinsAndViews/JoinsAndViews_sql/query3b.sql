/*use ci402_teaching** change to your own db name*/

select CustID, fName, sName, City
from tCust;

select SalesOrderID, OrderDate, CustomerID from tOrder;



