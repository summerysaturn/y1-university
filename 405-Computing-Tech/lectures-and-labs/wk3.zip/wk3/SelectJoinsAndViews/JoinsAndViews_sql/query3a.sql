/*use ci402_teaching** change to your own db name*/

SELECT SalesOrderID, OrderDate, CustomerID, fName, sname, City

FROM tOrder

INNER JOIN  tCust

ON tOrder.CustomerID = tCust.CustID

