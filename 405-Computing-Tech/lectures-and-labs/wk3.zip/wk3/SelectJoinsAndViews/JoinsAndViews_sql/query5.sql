/*NOTE: you cannot create a view in this DB - use your own
where you have permissions*/
use ci402_teaching; /*change this*/
GO


CREATE VIEW vCustOrderDisplay AS

SELECT SalesOrderID, 
OrderDate, 
CustomerID, 
fName, 
sName,
City
FROM tOrder
INNER JOIN tCust 
ON tOrder.CustomerID = tCust.CustID