/*NOTE: you cannot create a view in this DB - use your own
where you have permissions*/



select * from vCustOrderDisplay
