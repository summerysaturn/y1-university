/***edit this to use your own db****/
/*      use xxxxxxxxx     */
/***edit this to use your own db****/

select salesOrderID, orderDate, customerID, totaldue
from tOrder
where customerID < 5
order by CustomerID