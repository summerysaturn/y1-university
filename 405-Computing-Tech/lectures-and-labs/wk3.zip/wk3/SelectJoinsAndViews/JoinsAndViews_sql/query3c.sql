/*use ci402_teaching** change to your own db name*/

SELECT SalesOrderID, 
OrderDate, 
CustomerID, 
fName, 
sName,
City
FROM tOrder
INNER JOIN tCust 
ON tOrder.CustomerID = tCust.CustID

