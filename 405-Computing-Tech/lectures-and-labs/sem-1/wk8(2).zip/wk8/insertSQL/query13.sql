Update tCust3
set DeleteFlag = 'TRUE'		/*change TRUE to 1 for MySQL (diff data type)*/
where city = 'Salt Lake City';

select *
from vtcust			/*MySQL case sensitive - change ???)*/
order by city;

select *
from tCust3
order by city;