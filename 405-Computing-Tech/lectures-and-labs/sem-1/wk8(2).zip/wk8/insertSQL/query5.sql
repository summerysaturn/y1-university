/*before*/
select * from tCust2 where custID = 1;

UPDATE tCust2
set fName = 'Harry'
where custID = 1;

/*after*/
select * from tCust2 where custID = 1;

/*might see same record twice, if you were allowed to 'double copy tCust into tCust2 at query 3 i.e. no PK - compare tCust2 to tCust*/