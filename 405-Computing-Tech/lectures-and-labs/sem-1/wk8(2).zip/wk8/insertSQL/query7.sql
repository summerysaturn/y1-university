UPDATE tCust2			/*table to change*/
SET PostalCode = 'M4'		/*field(s) to change*/
, city = 'Toronto, Ontario'
WHERE city = 'Toronto'		/*identifier of records to change*/

