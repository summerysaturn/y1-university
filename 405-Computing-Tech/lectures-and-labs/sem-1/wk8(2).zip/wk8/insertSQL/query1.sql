/*SQL Server*/
select * INTO tCust2
	from tCust

/*MySQL*/
create table tCust2
as
select * from tCust