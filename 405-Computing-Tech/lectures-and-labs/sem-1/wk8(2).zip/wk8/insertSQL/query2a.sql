Insert Into tCust2
(CustID			/*fields don't have */
, fName			/*to be default order*/
, sName
, addressLine1
, city
, country
, deleteFlag
, catID)
values (
409
, 'Larry'			/*have to include required (not null) fields*/
, 'Jones'
, 'New Cottage'
, 'Farm Lane'
, 'Brighton'
, 1
, 'S')