select * from tCust2 where city like 'Miami%';

UPDATE tCust2
SET City = 'Miami FLA'
WHERE city = 'Miami';

select * from tCust2 where city like 'Miami%';
