delete from tCust3
where city = 'Portland'