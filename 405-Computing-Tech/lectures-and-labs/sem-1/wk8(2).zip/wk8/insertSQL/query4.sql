ALTER TABLE tCust2
ADD postalCode varchar(7)

/*examine table afterwards. Is field allowed to be null?*/