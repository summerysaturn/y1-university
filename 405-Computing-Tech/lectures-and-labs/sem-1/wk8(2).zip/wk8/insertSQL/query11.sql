UPDATE tCust3
SET deleteFlag = 0;

UPDATE tCust3
SET deleteFlag = 1
where custID <10;