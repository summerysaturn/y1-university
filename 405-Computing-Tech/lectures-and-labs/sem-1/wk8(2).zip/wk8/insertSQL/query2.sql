insert into tCust2			
values 
(401				/*custID*/
, 'Harry'				/*fName*/
, 'Robinson' 			/*sName*/
, '15 Acacia Ave'			/*addressLine1*/
, ''				/*addressLine2 (why blank?)*/
, 'London'				/*city*/
, 'UK'				/*country*/
, '1'				/*delete flag*/
, 'B'				/*customer category*/
)
/*fields do have to be in default order - not recommended - why not? */