create view vtCust
AS
Select * from tCust3
where deleteflag = 0;

create view vtArchiveCust
AS
select * from tCust3
where DeleteFlag = 1;

/*note: in SQL Server, you have to run these 2 queries separately (one at a time) or you will get an error saying 'CREATE VIEW must be the first statement in a query batch */