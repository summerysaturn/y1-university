select * from vtCust

