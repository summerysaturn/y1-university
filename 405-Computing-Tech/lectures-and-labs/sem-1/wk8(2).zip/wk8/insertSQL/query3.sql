/*will work in both

insert INTO tCust2
	select * from tCust 

	--needs table to already exist
	--can run again and again (as long as doesn't
	--break primary key rules)

/*why doesn't this (below) work in mysql, but will work in SQLServer?
insert INTO tCust2
	select * from tcust   */

