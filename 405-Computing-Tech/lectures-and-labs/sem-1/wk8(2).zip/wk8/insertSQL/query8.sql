/*SQL Server */
select * into tCust3
from tCust2


/*MySQL*/
create table tCust3
as
select * from tCust2