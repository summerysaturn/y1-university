/*this is a comment
change jh1033 to YOUR OWN DB NAME 
SQLServer prepend query with use jh1033 please change db name to yours
MySQL - check the breadcrumb trial*/


select * from tProduct


