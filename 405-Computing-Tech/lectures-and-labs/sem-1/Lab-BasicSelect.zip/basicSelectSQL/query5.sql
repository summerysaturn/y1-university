
/*check you are using your own db*/


select salesOrderId, subtotal, orderDate 
from tOrder
where orderDate <'2002-09-01'

/*how do you know HOW MANY total rows in the order table - 
look back at query4 for help and see if you can adapt it
to look at the order table*/




