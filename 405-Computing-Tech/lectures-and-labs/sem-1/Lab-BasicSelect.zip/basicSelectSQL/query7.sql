/*change to your own db name*/
use jh1033/**really do change it.*/

select ProductID, Name, ProductNumber 
from tProduct
WHERE Name LIKE 'Chain%'