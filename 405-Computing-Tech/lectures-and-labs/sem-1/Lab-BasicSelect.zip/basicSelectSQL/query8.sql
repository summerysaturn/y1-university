select ProductID, Name, ProductNumber 
from tProduct
WHERE Name LIKE '%socks';

select ProductID, Name, ProductNumber 
from tProduct
WHERE Name LIKE 'socks%';

select ProductID, Name, ProductNumber 
from tProduct
WHERE Name LIKE '%socks%';

/*why does only last query find anything 
(may need to scroll down results box to see it)*/

/*wildcard pattern matching
common in many computer progs
'%socks' - this means  - ends with 'socks'
Is it case-sensitive - amend your data and see.*/