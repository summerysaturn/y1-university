/*check you are in the correct database*/


select custID, fName, sName, City 
from tCust;

/*what's the difference betwen these two queries?*/

select custID, fName, sName, City 
from tCust
where city = 'Miami';

select count(*) from tCust
/*record the result - this is how many records are in the table*/

/*now add another customer 
(MSSQL click on customer table, select 'Edit Top 200 Rows' / 
MySQL click on customer table, go to insert tab
add another customer with city 'Miami'
and re-run the query, checking the number of rows in the result */