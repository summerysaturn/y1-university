select * from tProduct where ReorderPoint < 100

/*are these in order of anything? how could you change it?*/