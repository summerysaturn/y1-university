use ci402_teaching

/*MSSQL only, because you need to use one of my tables - hence USE statement above*/
/*for MySQL, see folder titled q11-MySQL to create and populate tPrice table. 

select * from tPrice

/*EXTENSION TASK
find the current price for a given product
start by selecting just ONE product ID and looking at the data there.
How can you manipulate this using select statement elements 
that we have examined this week?*/