CREATE TABLE tPrice(
	 ProductID int  NOT NULL,
	 StartDate datetime NOT NULL,
	 EndDate datetime NULL,
	 ListPrice decimal (18,4) NOT NULL,
	ModifiedDate datetime NOT NULL
) 