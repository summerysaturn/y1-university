For the Query 11 extension task. 

[go back to week 1 if you can't remember how to create a table. 

1. Create the table using createPrice.sql file
2. Populate table using tPrice.sql file