
/*check you are using your own db*/

select salesOrderId, subtotal, orderDate  
from tOrder					
where orderDate <'2002-09-01'		
order by orderDate	

/*default sort order is ASC (ascending)
put DESC at end (descending) and note the difference*/

/*Note: you don�t have to SHOW the column that you are ordering by � 
try this query without orderDate in the field list (first line)*/
