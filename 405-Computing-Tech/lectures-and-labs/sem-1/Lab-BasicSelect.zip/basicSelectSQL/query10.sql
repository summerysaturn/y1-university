select Name, ReorderPoint from tProduct
where ReorderPoint != 3

/*change the ReorderPoint number here to 375. 
What happens? Why?
NOTE: numbers don't need quote marks round them*/