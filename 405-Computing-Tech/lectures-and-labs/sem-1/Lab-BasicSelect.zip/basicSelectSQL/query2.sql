/*this is a comment
change jh1033 to YOUR OWN DB NAME 
SQLServer prepend query with use jh1033 please change db name to yours
MySQL - check the breadcrumb trial*/

/*show only some fields - note no comma after last field
look at the fields in your table and try to change this to show other fields instead*/

select Name, productID, color, ListPrice from tProduct;
