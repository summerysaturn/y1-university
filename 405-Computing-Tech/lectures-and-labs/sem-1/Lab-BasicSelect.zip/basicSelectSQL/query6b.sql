
select * from tProduct
order by Reorderpoint desc


/*MSSQL version - change to make this work in MySQL*/
select top 1 Name, ReorderPoint
from tProduct

/*MSSQL version - change to make this work in MySQL*/
select top 1 Name, ReorderPoint
from tProduct
order by ReorderPoint desc


/*why do these give different results?
Which one tells me the highest reorder point
What if you change desc to asc in final query? */