/*check you are using your own db*/

/*SQL Server version*/
select top 1 Name, ReorderPoint
from tProduct

/*MySQL Server version*/
select  Name, ReorderPoint, ListPrice
from tProduct limit 1

/*this is one of the few SQL differences that we will see in the SQL syntax bewteen the different DBMSs*/

select Name, ReorderPoint
from tProduct

/* how would you find the top 10 records? 
what does this even mean without a defined order?*/

/*compare outcomes of these queries - MySQL version*/
select  Name, ReorderPoint, ListPrice
from tProduct 
order by Name
limit 1


select  Name, ReorderPoint, ListPrice
from tProduct 
order by ReorderPoint
limit 1

select  Name, ReorderPoint, ListPrice
from tProduct 
order by ListPrice
limit 1