/*use [your-own-database]*/

select *
from tOrderLine;

select COUNT(ProductID) AS TotalRecords 
from tOrderLine;