/*use [your-own-database]*/


select MAX(LineTotal) AS MaxLineTotal 
from tOrderLine

/*try this on a text and date field e.g. name in customer - what happens?*/