/*use [your-own-database]*/

select ol.productid, sum(OrderQty) AS TotalQty
from  tProduct p
inner join  tOrderLine ol
ON p.productid = ol.productid
group by ol.productid
HAVING sum(OrderQty) > 1000;

/*notice the p and ol as shortcuts for product and orderline, created when the table name is first mentioned in the FROM clause - you can use the shortcut before you create it!*/