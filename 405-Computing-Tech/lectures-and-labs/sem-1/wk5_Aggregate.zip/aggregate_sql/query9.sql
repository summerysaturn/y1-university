/*use [your-own-database]*/

select 
ol.productID,
name,
color,
reorderpoint,
sum(OrderQty) AS TotalQty
from tProduct p

inner join tOrderLine ol

ON p.productid = ol.productid
/*take out name, color and reorder point and look at error
v. common error with aggregate functions - this is how 
to avoid it - include field items in group by */
group by ol.productid, name, color, reorderpoint

HAVING sum(OrderQty) > 1000