/*use [your-own-database]*/

select 
productid,
name,
color,
reorderpoint

from tProduct

where productid IN 

(select productid 
from tOrderLine
group by productid
having sum(OrderQty) > 1000)
