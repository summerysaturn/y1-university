/*use [your-own-database]*/


SELECT * FROM tOrderLine
WHERE ProductID = 802