/*use [your-own-database]*/



SELECT ProductID, 
SUM(OrderQty) AS TotalQty, 
SUM(LineTotal) 
AS TotalPrice 
FROM tOrderLine
WHERE ProductID > 990
GROUP BY ProductID
