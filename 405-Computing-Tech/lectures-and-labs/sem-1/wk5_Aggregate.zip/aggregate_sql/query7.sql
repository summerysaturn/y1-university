/*use [your-own-database]*/

SELECT ProductID, SUM(OrderQty) AS TotalQty, SUM(LineTotal) AS TotalPrice 
FROM tOrderLine
WHERE ProductID > 800
GROUP BY ProductID
HAVING SUM(OrderQty) > 400
ORDER BY ProductID asc
