/*use [your-own-database]*/


SELECT ProductID, 
AVG(OrderQty) AS AvgQty, 
AVG(LineTotal) AS AvgLineTotal, 
AVG(UnitPrice) as AvgUnitPrice 

FROM tOrderLine

GROUP BY ProductID

ORDER BY ProductID asc