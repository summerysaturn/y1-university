/*use [your-own-database]*/

SELECT ProductID, SUM(OrderQty) AS TotalQty, 
SUM(LineTotal) AS TotalPrice 
FROM tOrderLine
GROUP BY ProductID
HAVING SUM(OrderQty) > 1000
ORDER BY ProductID asc
