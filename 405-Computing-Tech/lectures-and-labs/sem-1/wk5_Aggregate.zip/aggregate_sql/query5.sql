/*use [your-own-database]*/

select SUM(OrderQty) AS TotalQty 
from tOrderLine
