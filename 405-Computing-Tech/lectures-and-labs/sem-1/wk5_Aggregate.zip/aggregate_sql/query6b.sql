SELECT p.productID, p.Name, SUM(OrderQty) AS TotalQty, 
SUM(LineTotal) AS TotalPrice 
FROM tProduct p
INNER JOIN tOrderLine ol
ON p.productID = ol.productID
WHERE p.productID >200
GROUP BY p.productID, p.name
HAVING SUM(OrderQty) > 500
ORDER BY ProductID asc;

/*try taking both the WHERE and then the HAVING clauses out
then add them back in one at a time and compare the outcomes*/