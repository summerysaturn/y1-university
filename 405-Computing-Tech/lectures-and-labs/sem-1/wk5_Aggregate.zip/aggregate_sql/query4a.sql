/*use [your-own-database]*/

SELECT ProductID, 
AVG(CAST(OrderQty as decimal(10,2))) as avgQty,
AVG(LineTotal) AS AvgLineTotal, 
AVG(UnitPrice) as AvgUnitPrice 
FROM tOrderLine
GROUP BY ProductID
ORDER BY ProductID asc;
