/*use [your-own-database]*/


SELECT ProductID,  
SUM(OrderQty) AS TotalQty, 		/*calc'ed value, new col. name*/

SUM(LineTotal) AS TotalPrice    	 /*calc'ed value, new col. name*/

FROM tOrderLine
GROUP BY ProductID		/*one value per product*/
ORDER BY ProductID asc
