/*use your own db*/
/*adjust to make it work - look at errors*/

SELECT 
fName,
sName,
City

FROM tCustomer
where City = 'Toronto' OR City = 'Greensboro'
