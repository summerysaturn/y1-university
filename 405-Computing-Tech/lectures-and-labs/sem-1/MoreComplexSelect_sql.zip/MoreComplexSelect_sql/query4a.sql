/*use [yourowndatabase]*/
/*adjust to make it work*/

SELECT * FROM tCust
where city='Toronto'
and categoryID='S'




