/*how would you change this to find all other cities BUT NOT THESE THREE*/

SELECT  * 
FROM tCust
WHERE city IN ('Salt Lake City', 'Toronto', 'Berlin')
ORDER BY city