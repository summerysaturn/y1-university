/*use [yourowndatabase]*/

SELECT * FROM tCust
where city='Toronto'
AND catID='S';


SELECT * FROM tCust
where city='Toronto'
OR catID='S'


