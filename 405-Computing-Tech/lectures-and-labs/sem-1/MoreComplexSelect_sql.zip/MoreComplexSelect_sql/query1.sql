use xxxx /*change to [your db]*/


select * from vCustOrd


/*how would you put this in oder of (e.g.) city*/
