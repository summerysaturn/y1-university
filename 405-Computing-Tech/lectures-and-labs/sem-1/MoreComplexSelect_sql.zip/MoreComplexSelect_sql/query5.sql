/*use your own db
could you order these in a more useful way?
- would be easier to understand if you add an order by clause to order the results on the restricted field  e.g. for the first one, order by city, then you can check your results more easily*/


/*note - this is INCLUSIVE RANGE*/

SELECT *
FROM vCustOrd
WHERE city BETWEEN 'Berlin' AND 'Chantilly';

/*change the order (which field?) on this one so you can check the results*/
SELECT * 
FROM vCustOrd
WHERE custID BETWEEN 5 AND 40;

/*inclusive is really useful for dates*/
SELECT *
FROM vCustOrd
WHERE orderDate BETWEEN '2002-05-01' AND '2002-05-31';