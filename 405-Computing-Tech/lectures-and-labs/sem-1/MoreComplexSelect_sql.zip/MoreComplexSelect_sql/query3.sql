/*use your own db*/

SELECT 
fName,
sName,
City

FROM tCust
where City = 'Toronto' AND City = 'Greensboro'


