/*use [YOUR_OWN_DATABASE]*/
/*change it to make it work*/


CREATE VIEW vGoldSilverCust AS
SELECT 
fName,
sName,
catID

FROM  tCust

WHERE catID != 'B';



/*now show all the data from this new view and count the records

Edit some customer records by changing catID to T for Titanium who were previously G for Gold. What happens to the number of customers in the view?*/







