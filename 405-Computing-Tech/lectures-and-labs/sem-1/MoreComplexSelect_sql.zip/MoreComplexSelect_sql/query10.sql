

select *
from tProduct
where productid IN 
(select productid
from tOrderLine
where orderqty > 30)
order by productid desc;

select *
from tOrderLine
where orderqty > 30
order by productid desc

/*why are there not the same number of rows in each? CLUE: take out the distinct key word*/