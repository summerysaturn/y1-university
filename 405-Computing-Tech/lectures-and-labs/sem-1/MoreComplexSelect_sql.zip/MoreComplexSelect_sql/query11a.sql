/*developing the query*/

/*find London customers (note use of c to replace tCust)*/
select * from tCust c
where city = 'London';

/*find their orders*/
select * from tOrder where customerID = 70;

/*join London cust to order (note use of c to replace tCust / o to replace tOrder))*/
select * from tCust c
inner join tOrder o
on c.custID = o.customerID
where city = 'London';

/*join that to orderLine */
select * from tCust c
inner join tOrder o
on c.custID = o.customerID
inner join tOrderLine ol
on o.salesOrderID = ol.salesOrderID
where city = 'London';

/*join that to product - find what they've ordered*/
select * from tCust c
inner join tOrder o
on c.custID = o.customerID
inner join tOrderLine ol
on o.salesOrderID = ol.salesOrderID
inner join tProduct p
on ol.productID = p.productID
where city = 'London';