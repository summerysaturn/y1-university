/*use [yourowndatabase]*/

SELECT * FROM tCust
where city='Toronto'