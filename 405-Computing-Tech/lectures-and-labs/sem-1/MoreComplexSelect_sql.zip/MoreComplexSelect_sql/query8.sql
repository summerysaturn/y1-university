CREATE VIEW vGoldSilverRobust
AS SELECT fName, sName, catID 
WHERE tcust.catID
IN ('G','S');