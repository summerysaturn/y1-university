select * from tCust 
inner join tOrder 
on tCust.custID = tOrder.customerID
where custID in
	(select custID from tCust 
	where sname = 'Allen' 
	or sname = 'Alexander')