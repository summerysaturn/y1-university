/*USE [your own database]*/

SELECT 
tProduct.productID, 
Name, 
city

FROM  tCust
INNER JOIN tOrder
ON tCust.CustID = tOrder.CustomerID 

INNER JOIN tOrderLine
ON tOrder.SalesOrderID = tOrderLine.SalesOrderID

INNER JOIN tProduct 
ON tOrderLine.productid =  tProduct.productid

WHERE city = 'London'

