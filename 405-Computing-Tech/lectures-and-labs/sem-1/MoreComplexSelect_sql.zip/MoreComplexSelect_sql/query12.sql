select * from tProduct where productID IN
	(select productID from tOrderLine where salesOrderID IN
		((select salesOrderID from tOrder where customerID IN 
			(select custID from tCust where city = 'London'))));