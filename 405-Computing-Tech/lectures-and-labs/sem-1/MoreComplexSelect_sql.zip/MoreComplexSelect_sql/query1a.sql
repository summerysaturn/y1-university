/*adjust to make it work - look at errors*/

select fname, sname, city
from tCustomer
where city = 'Toronto'