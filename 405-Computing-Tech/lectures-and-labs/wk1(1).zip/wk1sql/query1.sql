select *
from tproduct