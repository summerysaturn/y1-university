select *
from tcust