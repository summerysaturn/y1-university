NOTE: this SQL will run on our CSSQL server at university, take data from an existing database and copy it to yours. 

Instructions for home use: 

If you are running an SQL Server database at home (purely optional) then you will need to use the SQL and data in the MySQL folder to:

-create tables
-use the CSV files to populate these tables (instructions to follow in next few weeks as this is not essential - you can always use MySQL via BrightonDomains from home.