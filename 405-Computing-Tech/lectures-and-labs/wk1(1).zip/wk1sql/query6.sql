select *
from tOrderLine ol
inner join tProduct p
on ol.ProductID= p.productID